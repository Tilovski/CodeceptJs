Feature('Order');

Scenario('Log in and order', ({ I , locatorsPage1 }) => {

    I.amOnPage('https://www.saucedemo.com/');
    locatorsPage1.LogInUser('standard_user','secret_sauce','Martin','Tilovski','7000');
    

});


