const { I } = inject();

module.exports = {

    locators:{
        log_inButton:'#login-button',
        txtUsername:'#user-name',
        txtPassword:'#password',
        Backapck:'//*[@id="item_4_title_link"]/div',
        AddToCart:'#add-to-cart-sauce-labs-backpack',
        BackToProducts:'#back-to-products',
        ShopingCart:'//*[@id="shopping_cart_container"]/a',
        ChekOut:'#checkout',
        txtName:'#first-name',
        txtLastName:'#last-name',
        txtZipCode:'#postal-code',
        ContinueButton:'#continue',
        FinishButton:'//*[@id="finish"]',
        BackHomeButton:'#back-to-products',

      },
    
    
       LogInUser(username,password,Name,LastName,ZipCode){
        I.fillField(this.locators.txtUsername, username);
        I.fillField(this.locators.txtPassword, password);
        I.click(this.locators.log_inButton);
        I.click(this.locators.Backapck);
        I.click(this.locators.AddToCart);
        I.click(this.locators.BackToProducts);
        I.click(this.locators.ShopingCart);
        I.click(this.locators.ChekOut);
        I.fillField(this.locators.txtName, Name);
        I.fillField(this.locators.txtLastName , LastName);
        I.fillField(this.locators.txtZipCode , ZipCode);
        I.click(this.locators.ContinueButton);
        I.click(this.locators.FinishButton);
        I.click(this.locators.BackHomeButton);
        
}
}