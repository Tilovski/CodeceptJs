const { Accessibility } = require("puppeteer");

Feature('DemoNop');

Scenario('Ttesting DemoNopRegister adn log in', ( { I , locatorsPage } ) => {

    I.amOnPage('https://demo.nopcommerce.com');
    
    

   
      rand = Math.floor(Math.random()* 1000);
      email ="m.tilovski" + rand + "@gmail.com";


    
    

    locatorsPage.RegisterUser('Martin','Tilovski',email,'REK','123456789','123456789');



    

})