const { I } = inject();

module.exports = {

  Locators:{
  //homepage
  RegisterButton:'ico-register',
  LogInButton:'#ico-login',
  WishListButton:'#wishlist-label',
  ShopingCartButton:'#cart-label',
  txtSearch:'#small-searchterms',
  SearchButton:'#//*[@id="small-search-box-form"]/button', 
  Computers:'/html/body/div[6]/div[2]/ul[1]/li[1]/a',
  Electronics:'#/html/body/div[6]/div[2]/ul[1]/li[2]/a',
  Apparel:'#/html/body/div[6]/div[2]/ul[1]/li[3]/a',
  DigitalDownload:'#/html/body/div[6]/div[2]/ul[1]/li[4]/a',
  Books:'#/html/body/div[6]/div[2]/ul[1]/li[5]/a',
  Jewelry:'#/html/body/div[6]/div[2]/ul[1]/li[6]/a',
  GiftCards:'#/html/body/div[6]/div[2]/ul[1]/li[7]/a',

  //Register
  MaleRadio:'#gender-male',
  FemaleRadio:'#gender-female',
  txtFirstName:'#FirstName',
  txtLastName:'#LastName',
  DayOfBirth:'DateOfBirthDay',
  MonthOfBirth:'DateOfBirthMonth',
  YearOfBirth:'DateOfBirthYear',
  txtEmail:'#Email',
  txtCompanyName:'#Company',
  NewsLetterChekBox:'#Newsletter',
  txtPassword:'#Password',
  txtConfirmPassword:'#ConfirmPassword',
  Register:'#register-button',


  },


  

  async RegisterUser(FirstName,LastName,Email,CompanyName,Password,ConfrimPassword)
  {
  I.click('Register');
  I.see('Your Personal Details');
  I.click(this.Locators.MaleRadio);
  I.fillField(this.Locators.txtFirstName, FirstName);
  I.fillField(this.Locators.txtLastName, LastName);
  I.selectOption(this.Locators.DayOfBirth , '29');
  I.selectOption(this.Locators.MonthOfBirth, 'March');
  I.selectOption(this.Locators.YearOfBirth, '2001');
  I.fillField(this.Locators.txtEmail, Email);
  I.fillField(this.Locators.txtCompanyName,CompanyName);
  I.fillField(this.Locators.txtPassword, Password);
  I.fillField(this.Locators.txtConfirmPassword, ConfrimPassword);
  I.click(this.Locators.Register);
  await I.see('Your registration completed');
  I.wait(5);





  }


 


  }



