const { I } = inject();

module.exports = {

  locators:{
    txtUsername:'#user-name',
    txtPassword:'#password',
  },
    log_inButton:'#login-button',


   LogInUser(username,password){
    I.fillField(this.locators.txtUsername, username);
    I.fillField(this.locators.txtPassword, password);
    I.click(this.log_inButton);

}
}