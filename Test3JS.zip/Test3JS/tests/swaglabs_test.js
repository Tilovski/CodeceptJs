Feature('swaglabs');

Scenario('Ttesting swaglabs log in', ( { I , locatorsPage } ) => {

    I.amOnPage('https://www.saucedemo.com/');
    locatorsPage.LogInUser('standard_user','secret_sauce');

});
